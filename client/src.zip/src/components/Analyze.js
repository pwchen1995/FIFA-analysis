import React from 'react';
import BackGroundImage from './../FIFA-logo.jpg';


class AnalyzePage extends React.Component {

    render() {
        return (
        <div className="padded-page FIFA_wrap">
            <center>
            <div id = "SelectLeague" className = "dropdown" onChange ={this.selectLeague}>
                <h2>Welcome to FIFA Analysis</h2>
                <p>Analyzing ...</p>
                <p>League: {this.props.League}</p>
                <p>Team: {this.props.Team}</p>
                <p>Season: {this.props.Season}</p>
                <img src={BackGroundImage} alt="bg"></img>
                <p></p>
                <p></p>
                <p style={{fontStyle: "italic"}}>Version CptS 575 Final Project</p>
            </div>
            </center>
        </div>
        );
    }   
}

export default AnalyzePage;