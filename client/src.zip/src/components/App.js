import React from 'react';
import NavBar from './NavBar.js';
import SideMenu from './SideMenu.js';
import AppMode from "./../AppMode.js"
import LeaguePage from './LeaguePage.js';
import TeamsPage from './TeamsPage.js';
import AboutBox from './AboutBox.js';
import SeasonsPage from './SeasonsPage.js';
import Analyze from './Analyze.js';

const modeTitle = {};
modeTitle[AppMode.LEAGUE] = "FIFA Analysis";
modeTitle[AppMode.TEAMS] = "FIFA Analysis";
modeTitle[AppMode.SEASONS] = "FIFA Analysis";

const modeToPage = {};
modeToPage[AppMode.LEAGUE] = LeaguePage;
modeToPage[AppMode.TEAMS] = TeamsPage;
modeToPage[AppMode.SEASONS] = TeamsPage;

class App extends React.Component {

  constructor() {
    super();
    this.state = {mode: AppMode.LEAGUE,
                  menuOpen: false,
                  showAbout: false,
                  selectedLeague: true,
                  League: "",
                  selectedTeam: false,
                  Team: "",
                  selectedSeason: false,
                  Season: "",
                  Analyze: false};
  }
  componentDidMount() {
    // need to make the initial call to getData() to populate
    // data right away
    this.getData();

    // Now we need to make it run at a specified interval
    setInterval(this.getData, 5000); // runs every 5 seconds.
  }

  getData = () => {
    // do something to fetch data from a remote API.
    // console.log("Root: " + this.state.League)
  }
  
  handleChangeMode = (newMode) => {
    this.setState({mode: newMode});
  }

  openMenu = () => {
    this.setState({menuOpen : true});
  }
  
  closeMenu = () => {
    this.setState({menuOpen : false});
  }

  toggleMenuOpen = () => {
    this.setState(prevState => ({menuOpen: !prevState.menuOpen}));
  }

  closeAboutDialog = () =>{
    this.setState({showAbout: false});
  }
  showAboutDialog = () => {
    this.setState({showAbout: true});
  }
  selectLeague = (league) =>{
    this.setState({selectedLeague: false});
    this.setState({selectedTeam: true});
    this.setState({League: league});
    //alert("League Selected");
    console.log("League Selected: " + league)
  }
  selectTeam = (team) =>{
    this.setState({selectedTeam: false});
    this.setState({selectedSeason: true});
    this.setState({Team: team});
    //alert("League Selected");
    console.log("Team Selected: " + team)
  }
  selectSeason = (season) =>{
    this.setState({selectedSeason: false});
    this.setState({Analyze: true});
    this.setState({Season: season});
    //alert("League Selected");
    console.log("Season Selected: " + season)
  }

  render() {
    // const ModePage = modeToPage[this.state.mode];
    return (
      <div>
        {this.state.showAbout === true? <AboutBox closeAbout={this.closeAboutDialog}/>: null}
        <NavBar 
          title={modeTitle[this.state.mode]} 
          mode={this.state.mode}
          changeMode={this.handleChangeMode}
          menuOpen={this.state.menuOpen}
          toggleMenuOpen={this.toggleMenuOpen}
          showAbout={this.showAboutDialog}/>
          <SideMenu 
            menuOpen = {this.state.menuOpen}
            mode={this.state.mode}
            toggleMenuOpen={this.toggleMenuOpen}
            showAbout={this.showAboutDialog}/>
          {this.state.selectedLeague === true ? 
          <LeaguePage
          menuOpen={this.state.menuOpen}
          mode={this.state.mode}
          selectLeague={this.selectLeague}
          changeMode={this.handleChangeMode}/>:null}
          {this.state.selectedTeam === true ?
          <TeamsPage
          menuOpen={this.state.menuOpen}
          mode={this.state.mode}
          selectTeam={this.selectTeam}
          League={this.state.League}
          changeMode={this.handleChangeMode}/>:null}
          {this.state.selectedSeason === true ? 
          <SeasonsPage
          menuOpen={this.state.menuOpen}
          mode={this.state.mode}
          selectSeason={this.selectSeason}
          League={this.state.League}
          Team={this.state.Team}
          changeMode={this.handleChangeMode}/>: null}
          {this.state.Analyze === true ? 
          <Analyze
          menuOpen={this.state.menuOpen}
          mode={this.state.mode}
          selectSeason={this.selectSeason}
          League={this.state.League}
          Team={this.state.Team}
          Season={this.state.Season}
          changeMode={this.handleChangeMode}/>: null}
          {/* <ModePage 
            menuOpen={this.state.menuOpen}
            mode={this.state.mode}
            selectLeague={this.selectLeague}
            changeMode={this.handleChangeMode}/> */}
            <script src="https://d3js.org/d3.v6.min.js"></script>
        </div>
        
    );  
  }
}

export default App;