import React from 'react';
import BackGroundImage from './../FIFA-logo.jpg';


class SeasonsPage extends React.Component {

    selectSeason = (event) =>{
        this.props.selectSeason(event.target.value);
    }

    render() {
        return (
        <div className="padded-page FIFA_wrap">
            <center>
            <div id = "SelectTeam" className = "dropdown">
                <h2>Welcome to FIFA Analysis</h2>
                <p>League: {this.props.League}</p>
                <p>Team: {this.props.Team}</p>
                <p>Please Select a Season.</p>
                <select id="myDropdown" className="dropdown-content" onChange={this.selectSeason}>
                    <option value="0">Select Season</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
                <img src={BackGroundImage} alt="bg"></img>
                <p></p>
                <p></p>
                <p style={{fontStyle: "italic"}}>Version CptS 575 Final Project</p>
            </div>
            </center>
        </div>
        );
    }   
}

export default SeasonsPage;