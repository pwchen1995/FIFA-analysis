import React from 'react';
import BackGroundImage from './../FIFA-logo.jpg';
import Papa from 'papaparse';
import * as d3 from "d3";
import { tickStep } from 'd3';


class ResultDisplayPage extends React.Component {

    constructor(){
        super();
        this.myRef = React.createRef(); 
        this.myRefSum = React.createRef();
        this.state = {
            gameResultHome: [],
            gameResultAway: [],
            gameResult: [],
            gameDate: [],
            winningTrend: [],
            xaxis: [],
            topScorer: [],
            topAssister: [],
            homePos: [],
            awayPos: [],
            homeAtt: [],
            awayAtt: [],
            aveHomeAtt: "",
            aveAwayAtt: "",
            aveHomePos: "",
            aveAwayPos: "",
        }
        this.dataset = []
    }
    componentDidMount(){ 
        console.log(this.myRef);
        this.readDataBase(); //win trend 
        this.averagePos();
        this.TopScore();
        this.TopAssister();
        this.averageAtt();
        this.showAve();
    }

    showAve(){
        const d3TextHomePos= d3.select(this.myRefSum.current)
                    .append("h4");
        d3TextHomePos.text("Average possession as home team: ")
                    .append("h3")
                    .text(this.state.aveHomePos)
                    .append('p');

        const d3TextAwayPos= d3.select(this.myRefSum.current)
                    .append("h4");
        d3TextAwayPos.text("Average possession as away team: ")
                    .append("h3")
                    .text(this.state.aveAwayPos)
                    .append('p');
        const d3TextHomeAtt= d3.select(this.myRefSum.current)
                    .append("h4");
        d3TextHomeAtt.text("Average possession as home team: ")
                    .append("h3")
                    .text(this.state.aveHomeAtt)
                    .append('p');

        const d3TextAwayAtt= d3.select(this.myRefSum.current)
                    .append("h4");
        d3TextAwayAtt.text("Average possession as away team: ")
                    .append("h3")
                    .text(this.state.aveAwayAtt)
                    .append('p');
    }


    async averageAtt() {
        const parsed_data = await this.getData('./sortDate_matches.csv');
        const matchesData = parsed_data.data;
        // 25 = attempt home 26 away 22 home possesion 23 away possesion
        for (var i = 0; i < matchesData.length; ++i){
            const matchesDataSplit = matchesData[i];
            for (var i = 0; i < matchesData.length; ++i){
                const matchesDataSplit = matchesData[i];
                if (i == 0){
                    continue;
                }
                else{
                    console.log(matchesDataSplit[25],matchesDataSplit[26])
                    if (matchesDataSplit[6] == 10260){ // MAnchester United home
                        await this.setState(prevState => ({ homeAtt: prevState.homeAtt.concat(matchesDataSplit[25])}));
                    }
                    else {
                        await this.setState(prevState => ({ awayAtt: prevState.awayAtt.concat(matchesDataSplit[26])}));
                    }
                }
            }
        }
        var len = this.state.homeAtt.length;
        var aveHomeAtt = d3.sum(this.state.homeAtt)/len;
        var len1 = this.state.awayAtt.length;
        var aveAwayAtt = d3.sum(this.state.awayAtt)/ len1;
        aveHomeAtt = Math.round(aveHomeAtt);
        aveAwayAtt = Math.round(aveAwayAtt);
        await this.setState({aveAwayAtt: aveAwayAtt});
        await this.setState({aveHomeAtt: aveHomeAtt});
        console.log(this.state.aveHomeAtt);
    }
    async averagePos() {
        const parsed_data = await this.getData('./sortDate_matches.csv');
        const matchesData = parsed_data.data;
        // 25 = attempt home 26 away 22 home possesion 23 away possesion
        for (var i = 0; i < matchesData.length; ++i){
            const matchesDataSplit = matchesData[i];
            if (i == 0){
                continue;
            }
            else{
                console.log(matchesDataSplit[22],matchesDataSplit[23])
                if (matchesDataSplit[6] == 10260){ // MAnchester United home
                    await this.setState(prevState => ({ homePos: prevState.homePos.concat(matchesDataSplit[22])}));
                }
                else {
                    await this.setState(prevState => ({ awayPos: prevState.awayPos.concat(matchesDataSplit[23])}));
                }
            }
        }
        var len = this.state.homePos.length;
        var aveHomePos = d3.sum(this.state.homePos)/len-1;
        var len1 = this.state.awayPos.length;
        var aveAwayPos = d3.sum(this.state.awayPos)/ len1;
        aveHomePos = Math.round(aveHomePos);
        aveAwayPos = Math.round(aveAwayPos);

        await this.setState({aveAwayPos: aveAwayPos});
        await this.setState({aveHomePos: aveHomePos});
    }
    async getData(URL) {
        // create a function that returns a Promise that resolves when papa parse complete is called
        const papaParsePromise = blob => new Promise(resolve => Papa.parse(blob, { complete: resolve }));
        const response = await fetch(URL);
        const blob = await response.blob();
        const data = await papaParsePromise(blob);
        return data;
    };
    async TopScore() {
        const parsed_data = await this.getData('./08-09MUN.csv');
        const scoreData = parsed_data.data;
        var name = "";
        var score = 0;
        for(var i = 0; i < scoreData.length; ++i){
            const scoreDataSplit = scoreData[i];
            const current = scoreDataSplit[2];
            const diff = current - score;
            if(diff > 0){
                score = current;
                name = scoreDataSplit[1];
            }
        }
        console.log("Top scorer: " + name + "with score: " + score);
        await this.setState(prevState => ({ topScorer: prevState.topScorer.concat(name)}));
        await this.setState(prevState => ({ topScorer: prevState.topScorer.concat(score)}));

        const d3TextScore = d3.select(this.myRefSum.current)
                    .append("h4");
                    
        d3TextScore.text("Top Scorer: ")
                    .append("h3")
                    .text(name + ": " + score)
                    .append('p');
    }
    async TopAssister() {
        const parsed_data = await this.getData('./08-09MUN.csv');
        const scoreData = parsed_data.data;
        var name = "";
        var score = 0;
        for(var i = 0; i < scoreData.length; ++i){
            const scoreDataSplit = scoreData[i];
            const current = scoreDataSplit[3];
            const diff = current - score;
            if(diff > 0){
                score = current;
                name = scoreDataSplit[1];
            }
        }
        console.log("Top assister: " + name + "with score: " + score);
        await this.setState(prevState => ({ topAssister: prevState.topAssister.concat(name)}));
        await this.setState(prevState => ({ topAssister: prevState.topAssister.concat(score)}));

        const d3TextAssist = d3.select(this.myRefSum.current)
                    .append("h4");
                    
        d3TextAssist.text("Top Assister: ")
                    .append("h3")
                    .text(name + ": " + score)
    }
    async readDataBase() {
        const season = this.props.season;
        const parsed_data = await this.getData('./sortDate_matches.csv');
        const matchesData = parsed_data.data;
        for(var i = 0; i < matchesData.length; ++i){
            const matchesDataSplit = matchesData[i];
            if (matchesDataSplit[2] === season){
                const parseTime = d3.timeParse('%Y-%m-%d %I:%M:%S'); // parse time
                const time = parseTime(matchesDataSplit[4])
                const timeFormat = d3.timeFormat('%m %d, %Y')
                const normalDate = timeFormat(time);
                await this.setState(prevState => ({ gameDate: prevState.gameDate.concat(normalDate)}));
                if (matchesDataSplit[6] === 10260){ // home team
                    await this.setState(prevState => ({ gameResult: prevState.gameResult.concat(matchesDataSplit[24])}));
                }
                else{
                    await this.setState(prevState => ({ gameResult: prevState.gameResult.concat(matchesDataSplit[24]*-1)}));
                }
            }
        }
        //////////////////////////////
        // Calculate winning trend 
        /////////////////////////////
        for (var j = 0; j < this.state.gameResult.length; ++j){
            const score = this.state.gameResult[j];
            if (score < 0){ // losing 
                if(this.state.winningTrend.length === 0){
                    await this.setState(prevState => ({winningTrend: prevState.winningTrend.concat(0)}));
                }
                else{
                    const prev = this.state.winningTrend[j-1];
                    await this.setState(prevState => ({winningTrend: prevState.winningTrend.concat(prev+0)}));
                }
                await this.setState(prevState => ({xaxis: prevState.xaxis.concat(j)}));
            }
            else if (score > 0){ 
                if(this.state.winningTrend.length === 0){
                    await this.setState(prevState => ({winningTrend: prevState.winningTrend.concat(3)}));
                }
                else{
                    const prev = this.state.winningTrend[j-1];
                    await this.setState(prevState => ({winningTrend: prevState.winningTrend.concat(prev+3)}));
                }
                await this.setState(prevState => ({xaxis: prevState.xaxis.concat(j)}));
            }
            else{
                if(this.state.winningTrend.length === 0){
                    await this.setState(prevState => ({winningTrend: prevState.winningTrend.concat(1)}));
                }
                else{
                    const prev = this.state.winningTrend[j-1];
                    await this.setState(prevState => ({winningTrend: prevState.winningTrend.concat(prev+1)}));
                }
                await this.setState(prevState => ({xaxis: prevState.xaxis.concat(j)}));
            }
        }
        // console.log(matchesData);
        // console.log(this.state.xaxis, this.state.winningTrend);
        const data = this.setDataSet();
        this.displayD3(data);
    }
    setDataSet(){
        const d = [];
        d['date'] = this.state.gameDate;
        d['trend'] = this.state.winningTrend;
        this.setState({dataset: d});
        console.log(this.state.dataset);
        return d;
    }
    displayD3(data){
        const domainRange = d3.extent(this.state.winningTrend)

        const margin = { top: 10, right: 35, bottom: 20, left: 40 },
        width = 200,
        height = width
        const newData = data;
        const svg = d3 // append SVG and set eveiroment output
                    .select(this.myRef.current)
                    .append("svg")
                    .attr("width", width + margin.left + margin.right)
                    .attr("height", height + margin.top + margin.bottom + 50)
                    .append("g")
                    .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        // setup x axis
        var x = d3.scaleTime()
                    .domain([new Date(data.date[0]), new Date(data.date[37])])
                    .range([ 0, width ]);
                svg.append("g")
                    .attr("transform", "translate(0," + height + ")")
                    .call(d3.axisBottom(x).ticks(10))
                    .selectAll("text")	// rotate
                    .style("text-anchor", "end")
                    .attr("dx", "-.8em")
                    .attr("dy", ".15em")
                    .attr("transform", "rotate(-65)");
        // setup y axies
        var y = d3.scaleLinear()
                    .domain(d3.extent(data.trend))
                    .range([ height, 0 ]);
                svg.append("g")
                    .call(d3.axisLeft(y).ticks(10));

        //line 
        const line = d3.line()
                        .x(d => x(d.name))
                        .y(d => y(d.value))
        const lines = svg.append('g').attr('class', 'lines')

        // import
        lines
            .selectAll('.line-group')
            .data(newData)
            .enter()
            .append('g')
            .attr('class', 'line-group')
            .append('path')
            .attr('class', 'line')
            .attr('d', d => line(d))
            .style('stroke', 'blue')
            .style('fill', 'none');

        // svg.append('path')
        //     .data(data)
        //     .enter()
        //     .attr('d', d3.line()
        //                   .x(d => x(d.date))
        //                   .y(d => y(d.trend)))
        console.log(svg)
    }



    render() {
        return (
        <div className="padded-page FIFA_wrap">
            <center>
            <div id = "SelectLeague" className = "dropdown" ref={this.myRefSum}>
                <h2>Result</h2>
                {/* <p style={{fontStyle: "italic"}}>Version CptS 575 Final Project</p> */}
                <img src={BackGroundImage} alt="bg"></img>
            </div>
            <div ref={this.myRef}>
            </div>
            <p></p>
            <p></p>
            <p style={{fontStyle: "italic"}}>&copy;Version CptS 575 Final Project</p>
            </center>
        </div>
        );
    }   
}

export default ResultDisplayPage;